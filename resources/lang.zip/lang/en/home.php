<?php
return [
	'about_vocational_title' => "What Is Vocational Education ?",
	"about_vocational_desc" => "Vocational education is an education system that applies 80% practice as well as 20% theory.",
	"about_vocational_button" => "Find Out Here",
	'events' => "Latest News & Events",
]
?>
