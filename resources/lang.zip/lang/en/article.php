<?php
return [
	"title" => "Newest News & Articles",
	"search" => "Search News Here",
	"button" => "Search",
]
?>