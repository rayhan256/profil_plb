<?php
return [
	'linkandmatch_title' => "What is Link and Match ?",
	'linkandmatch_short_desc' => "programs where learners will be assisted for internship and employment placements.",
	'link_button' => "I Want To Join",
	'sure_title' => "We Make Sure Students Are Ready to Work",
	"sure_content" => "We guarantee and commit to all students and students we have competent abilities and can compete in the world of work.",
	"sure_button" => "See Career Centre",
	"courses" => "Our Courses",
	"organizations" => "Our Student Organizations",
	"organizations_desc" => "This Is Our Student Organization To Support Learning on Campus",
]
?>
