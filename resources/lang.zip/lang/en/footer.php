<?php
return [
	"courses" => "Our Courses",
	"link_and_match" => "Link and Match",
	"student_work" => "Student Work",
	"blogs" => "Articles",
	"about" => "Abouts",
	"contact" => "Contact",
	"term" => "Term & Conditions",
	"back" => "Back To Top",
]
?>