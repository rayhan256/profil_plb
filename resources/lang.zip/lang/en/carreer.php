<?php
return [
	"main_title" => "Lp3I Polytechnic Career Center",
	"main_desc" => "Is a center of work placement and information source of companies in cooperation with Polytechnic LP3I",
	"partner" => "Cooperation Company",
	"partner_desc" => "This Is Our Cooperation Company",
	"testimonial" => "What Alumni Say About Polytechnic LP3I",
	"news" => "News About Career Centers",
];
?>