<?php
return [
	"home" => "Home",
	"about" => "About",
	"article" => "Article",
	"education" => "Education",
	"gallery" => "Galleries",
	"carrier_centre" => "Carrier Centre",
	"journal" => "Journal",
	"campus" => "Campus",
	"tridharma" => "Tridharma",
];
?>