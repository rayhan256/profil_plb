<?php
return [
	'linkandmatch_title' => "Apa Itu Link and Match ?",
	'linkandmatch_short_desc' => "Merupakan Progam dimana peserta didik akan dibantu untuk magang dan penempatan kerja. Sehingga Peserta Didik Tidak Perlu Khawatir Masalah Karir.",
	'link_button' => "Gabung Yuk",
	'sure_title' => "Kita Pastikan Mahasiswa Siap Bekerja",
	"sure_content" => "Kami menjamin dan berkomitmen kepada seluruh mahasiswa dan mahasiswi kami memiliki kemampuan yang kompeten dan dapat bersaing dalam dunia kerja.",
	"sure_button" => "Lihat Pusat Karir",
	"courses" => "Program Studi Kami",
	"organizations" => "Organisasi Mahasiswa Kami",
	"organizations_desc" => "Inilah Organisasi Mahasiswa Kami Untuk Mendukung Pembelajaran di Kampus",
]
?>
