<?php
return [
	'about_vocational_title' => "Apa Itu Pendidikan Vokasi ?",
	"about_vocational_desc" => "Pendidikan vokasi adalah sistem pendidikan yang menerapkan praktik 80% serta teori 20%.",
	"about_vocational_button" => "Lebih Lanjut Disini",
	'events' => "Berita dan Kegiatan Terbaru",
]
?>
