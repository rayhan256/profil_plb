<?php
return [
	"courses" => "Program Studi",
	"link_and_match" => "Link and Match",
	"student_work" => "Hasil Mahasiswa",
	"blogs" => "Artikel",
	"about" => "Tentang Kami",
	"contact" => "Kontak",
	"term" => "Syarat dan Ketentuan",
	"back" => "Kembali Ke Atas",
]
?>