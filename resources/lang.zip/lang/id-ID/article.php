<?php
return [
	"title" => "Berita & Artikel Terbaru",
	"search" => "Cari Berita Disini",
	"button" => "Cari",
]
?>