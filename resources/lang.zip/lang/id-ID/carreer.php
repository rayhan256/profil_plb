<?php
return [
	"main_title" => "Pusat Karir Politeknik LP3I",
	"main_desc" => "Merupakan pusat penempatan kerja dan sumber informasi perusahaan yang bekerjasama dengan Politeknik LP3I",
	"partner" => "Perusahaan Yang BekerjaSama",
	"partner_desc" => "Ini adalah beberapa perusahaan yang menjadi partner kami",
	"testimonial" => "Kata Alumni Tentang Kami",
	"news" => "Berita Tentang Pusat Karir",
];
?>