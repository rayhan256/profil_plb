<?php
return [
	"home" => "Beranda",
	"about" => "Tentang",
	"article" => "Artikel",
	"education" => "Pendidikan",
	"gallery" => "Galleri",
	"carrier_centre" => "Pusat Karir",
	"journal" => "Jurnal",
	"campus" => "Kampus",
	"tridharma" => "Tridharma",
];
?>